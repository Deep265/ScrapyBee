from django.contrib import admin
from .models import Signup
# Register your models here.
admin.site.register(Signup)
